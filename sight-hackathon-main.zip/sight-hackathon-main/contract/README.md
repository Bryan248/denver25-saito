# Sight-Hackathon Project

This contract manages Saito Memory resource authorization via EIP712

```shell
npx hardhat help
npx hardhat test
REPORT_GAS=true npx hardhat test
npx hardhat node
npx hardhat ignition deploy ./ignition/modules/AuthorizationContract.ts
```

drop table if exists saito_memory.memories;
drop schema if exists saito_memory cascade;

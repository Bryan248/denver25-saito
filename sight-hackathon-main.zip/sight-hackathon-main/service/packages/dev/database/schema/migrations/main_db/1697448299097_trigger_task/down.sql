drop table saito_tasks.trigger_tasks;
drop schema saito_tasks;

drop table if exists saito_common.air_drop;
drop table if exists saito_common.air_drop_user;
drop table if exists saito_common.referral;
drop table if exists saito_common.referral_history;
drop schema if exists saito_common cascade;

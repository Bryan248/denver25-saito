# openai

This library was generated with [Nx](https://nx.dev).

## Building

Run `nx build openai` to build the library.

## Running unit tests

Run `nx test openai` to execute the unit tests via [Jest](https://jestjs.io).

# libs-ethstorage

This library was generated with [Nx](https://nx.dev).

## Building

Run `nx build libs-storage` to build the library.

## Running unit tests

Run `nx test libs-storage` to execute the unit tests via [Jest](https://jestjs.io).

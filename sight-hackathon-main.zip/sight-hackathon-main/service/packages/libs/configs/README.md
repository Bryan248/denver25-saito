# configs

This library was generated with [Nx](https://nx.dev).

## Building

Run `nx build configs` to build the library.
